export class Funcionario {
    // nome!: string;
    // idade?: number;

    constructor(
        public nome: string,
        public idade: number) {}
}