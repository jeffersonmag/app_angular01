export interface Contato {
    _id?: string;
    nome: string;
    email : string;
    celular: string;    
}
