import { Injectable } from '@angular/core';
import { Contato } from '../classes/contato';

@Injectable({
  providedIn: 'root'
})
export class ContatosService {

  public getContatos() : Contato[] {
    return [
      { nome: 'Gerson', email: 'gerson@mail.com', celular: '99856-0077' },
      { nome: 'Arlindo', email: 'arlindo@mail.com', celular: '77854-8537' }
    ];
  }
  constructor() { }
}
